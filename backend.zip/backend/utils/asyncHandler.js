// Express 4 does not automatically pass rejected async functions to
// the error handler. This wrapper forwards errors to next(error).
const asyncHandler = (handler) => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

module.exports = asyncHandler;
